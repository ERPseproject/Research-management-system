@extends('user.master')
@section('title','Welcome Users')
@section('content')
    <h1>{{$name}}</h1>
    <h2>{{$title}}</h2>
@stop