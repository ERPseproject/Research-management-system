@extends('user.master')
@section('title','Welcome Edit')
@section('content')
    <h1>Edit</h1>
@stop