@extends('user.master')
@section('title','Welcome Homepage')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <br><br>
                <h1>Homepage</h1>
                <a href="{{route('user.create')}}">Go to input</a><br>
                {{view('user.tb')}}
            </div>
    </div>
</div>
@stop