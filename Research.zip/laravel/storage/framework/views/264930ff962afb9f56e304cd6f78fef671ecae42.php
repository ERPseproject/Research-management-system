<?php $__env->startSection('title','Welcome Homepage'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Homepage</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\resources\views/home.blade.php ENDPATH**/ ?>