<?php $__env->startSection('title','Welcome Users'); ?>
<?php $__env->startSection('content'); ?>
    <h1><?php echo e($name); ?></h1>
    <h2><?php echo e($title); ?></h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\resources\views/create/users.blade.php ENDPATH**/ ?>