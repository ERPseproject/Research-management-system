<?php $__env->startSection('title','Welcome Homepage'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Homepage</h1>
    <a href="<?php echo e(route('user.create')); ?>">Go to input</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\resources\views/user/home.blade.php ENDPATH**/ ?>