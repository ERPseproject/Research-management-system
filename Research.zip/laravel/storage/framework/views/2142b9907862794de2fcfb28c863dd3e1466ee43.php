<?php $__env->startSection('title','Welcome create'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12"><br>
    <h3 align="center">เพิ่มข้อมูล</h3><br>
    <form methd="post" action="<?php echo e(url('user')); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <input type="text" name="fname">
        </div>
        <div class="form-group">
            <input type="text" name="lname">
        </div>
        <div class="form-group">
            <input type="submit">
        </div>
    </form>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\resources\views/create.blade.php ENDPATH**/ ?>