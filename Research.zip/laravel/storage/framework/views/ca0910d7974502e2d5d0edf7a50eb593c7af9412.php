<?php $__env->startSection('title','Welcome create'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-12"><br>
    <div class="col-md-12"><br>
    <h3 align="center">เพิ่มข้อมูล</h3><br>
    <form method="post" action="<?php echo e(url('user')); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <input type="text" name="name" class="form-control">
        </div>
        <div class="form-group">
            <input type="text" name="lname" class="form-control">
        </div>
        
        <div class="form-group">
            <input type="submit" class="btn btn-primary">
        </div>
    </form>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\resources\views/user/create.blade.php ENDPATH**/ ?>