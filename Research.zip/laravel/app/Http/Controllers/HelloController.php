<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class HelloController extends BaseController
{
    function hello(){
        return 'Hi';
    }

    function home($name){
        return 'Hello '.$name;
    }

    function show(){
        return view('create.users')
        ->with('name','Guywerapat')
        ->with('title','Test');
    }
}
