<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    // Insert
    public static function getData()
    {
      $con = mysqli_connect("localhost","root","","laraveldb","3307");
      $sql = "SELECT id,fname,lname from users";
      $result = $con-> query($sql);
      if ($result-> num_rows > 0)
      {
        while ($row = $result-> fetch_assoc())
        {
          echo
          "<tr><td>". $row["id"]."</td>"
          ."<td>". $row["fname"]."</td>"
          ."<td>". $row["lname"]."</td>"
          ."</tr>";
        }
        $con-> close();
      }
    }
}
